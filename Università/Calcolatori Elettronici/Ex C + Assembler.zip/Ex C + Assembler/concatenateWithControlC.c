#include <stdio.h>
#define L 3

char concatenate_string_control_lenght(const char *first, const char *second){

	char *new;
	int len_first;
	int len_second;
}

for (len_first = 0; *first != '\0'; ++len_first){

	/* Ogni carattere della nuova stringa è uguale a quello dell prima */
	*new = *first;

	/* Incremento sia la prima stringa che la nuova stringa, in modo da accedere allo stesso in tutti e due i casi */
	++first;
	++new;

if (len_first < L){
	
for (len_second = 0; *second != '\0'; ++len_second)){
	*new = *second;
	++second;
	++new;
}

if (len_second < L){
	*new = '\0';
	}
	else
	{
	printf("Errore, la lunghezza della seconda stringa non è corretta");
	break;
	}
}

	else
	{
	printf("Errore, la lunghezza della prima stringa non è corretta");
	break;
	}

return final;
}

int main(void){

return 0;

};